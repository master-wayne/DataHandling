using UnityEngine;

public class RoomBoundary : MonoBehaviour
{
    public Bounds m_roomBounds => GetComponent<Collider>().bounds;
}
