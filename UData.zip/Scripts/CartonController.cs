using UnityEngine;

public class CartonController : MonoBehaviour
{
    [SerializeField]
    public GameObject m_cartonNormal;

    [SerializeField]
    public GameObject m_cartonDamaged;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Init();
    }

    private void Init()
    {
        m_cartonDamaged.gameObject.SetActive(true);
        m_cartonNormal.gameObject.SetActive(false);
    }

    public void ShowDamagedState(bool show)
    {
        m_cartonDamaged.gameObject.SetActive(show);
        m_cartonNormal.gameObject.SetActive(!show);
    }
}
