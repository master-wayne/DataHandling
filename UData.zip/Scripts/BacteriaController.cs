using UnityEngine;

public class BacteriaController : MonoBehaviour
{
    private Vector3 m_velocity;
    private RoomBoundary m_roomBoundary;

    public void Init(RoomBoundary roomBoundary)
    {
        m_roomBoundary = roomBoundary;
        m_velocity = Random.insideUnitSphere * 1.5f;
    }

    private void Update()
    {
        Vector3 pos = transform.position;
        Vector3 nextPos = pos + m_velocity * Time.deltaTime;
        Bounds b = m_roomBoundary.m_roomBounds;

        if (nextPos.x < b.min.x || nextPos.x > b.max.x)
        {
            m_velocity.x *= -1f;
        }
        if (nextPos.y < b.min.y || nextPos.y > b.max.y)
        {
            m_velocity.y *= -1f;
        }
        if (nextPos.z < b.min.z || nextPos.z > b.max.z)
        {
            m_velocity.z *= -1f;
        }

        transform.position += m_velocity * Time.deltaTime;
    }

    private void LateUpdate()
    {
        var cam = Camera.main;
        if(cam != null)
        {
            transform.LookAt(cam.transform);
            transform.Rotate(0f, 180f, 0f);
        }
    }
}