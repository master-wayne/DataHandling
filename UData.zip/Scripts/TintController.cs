using UnityEngine;
using UnityEngine.UI;

public class TintController : MonoBehaviour
{
    [SerializeField]
    public Image m_tintImage;

    [SerializeField]
    public Color m_damageState = new Color(0.2f, 0.4f, 1f, 0.5f);
    public Color m_normalState = new Color(1f, 0.5f, .1f, 0.25f);

    public void ShowDamagedState(bool show)
    {
        if(show)
        {
            m_tintImage.color = m_damageState;
        }
        else
        {
            m_tintImage.color = m_normalState;
        }
    }
}
