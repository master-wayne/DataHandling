using UnityEngine;

public class ToggleMachine : MonoBehaviour
{
    private bool m_isMachineOn = false;

    [SerializeField]
    public BacteriaSpawner m_BacteriaSpawner;

    [SerializeField]
    public CartonController m_CartonController;

    [SerializeField]
    public TintController m_tintController;

    public void Toggle()
    {
        m_isMachineOn = !m_isMachineOn;

        if (m_isMachineOn)
        {
            m_BacteriaSpawner.ShowBacteria(false);
            m_CartonController.ShowDamagedState(false);
            m_tintController.ShowDamagedState(false);
        }
        else
        {
            m_BacteriaSpawner.ShowBacteria(true);
            m_CartonController.ShowDamagedState(true);
            m_tintController.ShowDamagedState(true);
        }
    }
}
