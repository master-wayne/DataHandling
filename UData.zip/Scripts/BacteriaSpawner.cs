using System.Collections.Generic;
using UnityEngine;

public class BacteriaSpawner:MonoBehaviour
{
    public RoomBoundary m_roomBoundary;

    [SerializeField]
    public GameObject m_bacteriaPrefab;

    [SerializeField]
    public int m_bacteriaCount = 50;

    private List<GameObject> m_bacterias = new List<GameObject>();

    private void Start()
    {
        SpawnPlanes();
    }
    private void SpawnPlanes()
    {
        var bounds = m_roomBoundary.m_roomBounds;

        for(int i = 0; i < m_bacteriaCount; i++)
        {
            Vector3 pos = new Vector3(
                Random.Range(bounds.min.x, bounds.max.x),
                Random.Range(bounds.min.y, bounds.max.y),
                Random.Range(bounds.min.z, bounds.max.z)
                );
            
            var bacteria = Instantiate(m_bacteriaPrefab, pos, Quaternion.identity);
            bacteria.GetComponent<BacteriaController>().Init(m_roomBoundary);
            m_bacterias.Add(bacteria);
        }
    }
    public void ShowBacteria(bool visible)
    {
        foreach(var bacteria in m_bacterias)
        {
            if(bacteria != null)
            {
                bacteria.SetActive(visible);
            }
        }
    }
}